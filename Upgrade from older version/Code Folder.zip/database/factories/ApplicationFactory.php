<?php

/** @var Factory $factory */

use App\Admin\Application;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;

$factory->define(Application::class, function (Faker $faker) {
    return [
        //
    ];
});
