<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Oder;
use Faker\Generator as Faker;

$factory->define(Oder::class, function (Faker $faker) {
    return [
        //
    ];
});
