<html>
<head>
    <title>Buy cool new product</title>
</head>
<body>
<button id="checkout-button">Checkout</button>


</body>
</html>
