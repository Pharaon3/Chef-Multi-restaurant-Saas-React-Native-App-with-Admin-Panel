<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StoreSlider extends Model
{
    protected $guarded = [];
}
