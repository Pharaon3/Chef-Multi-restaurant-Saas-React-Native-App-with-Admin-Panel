
@extends('Home.home_layout.app')
@section('home_content')

    <div id="root">



    </div>
@endsection
