<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\SelectedSubscription;
use Faker\Generator as Faker;

$factory->define(SelectedSubscription::class, function (Faker $faker) {
    return [
        //
    ];
});
