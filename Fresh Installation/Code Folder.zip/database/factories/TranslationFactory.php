<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\translation;
use Faker\Generator as Faker;

$factory->define(translation::class, function (Faker $faker) {
    return [
        //
    ];
});
